# -*- coding: utf-8 -*-
from odoo import models, fields, api
from datetime import timedelta

class ParcPack(models.Model):
    _name = 'parc.pack'
    _description = "Pack Informatique"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'date_start desc'

    name = fields.Char(string="Nom du Pack", required=True, tracking=True)
    client_id = fields.Many2one('res.partner', string="Client", required=True, domain=[('is_client_it','=',True)], tracking=True)
    site_id = fields.Many2one('parc.client.site', string="Site", ondelete='restrict',
                              domain="[('partner_id','=',client_id)]")
    date_start = fields.Date(string="Date de démarrage", tracking=True)
    description = fields.Text(string="Description")

    materiel_ids = fields.One2many('parc.materiel', 'pack_id', string="Matériels")
    logiciel_ids = fields.One2many('parc.logiciel', 'pack_id', string="Logiciels")
    licence_ids  = fields.One2many('parc.licence', 'pack_id',  string="Licences")

    materiel_count = fields.Integer(string="Nombre de Matériels", compute='_compute_materiel_count')
    logiciel_count = fields.Integer(string="Nombre de Logiciels", compute='_compute_logiciel_count')
    licence_count  = fields.Integer(string="Nombre de Licences", compute='_compute_licence_count')

    @api.depends('materiel_ids')
    def _compute_materiel_count(self):
        for rec in self:
            rec.materiel_count = len(rec.materiel_ids)

    @api.depends('logiciel_ids')
    def _compute_logiciel_count(self):
        for rec in self:
            rec.logiciel_count = len(rec.logiciel_ids)

    @api.depends('licence_ids')
    def _compute_licence_count(self):
        for rec in self:
            rec.licence_count = len(rec.licence_ids)

    # ------ Les 3 méthodes manquantes pour les boutons smart ------
    def action_open_materiels(self):
        self.ensure_one()
        return {
            'name':        "Matériels",
            'type':        'ir.actions.act_window',
            'res_model':   'parc.materiel',
            'view_mode':   'kanban,list,form',
            'domain':      [('pack_id','=', self.id)],
            'context':     {'default_pack_id': self.id},
        }

    def action_open_logiciels(self):
        self.ensure_one()
        return {
            'name':        "Logiciels",
            'type':        'ir.actions.act_window',
            'res_model':   'parc.logiciel',
            'view_mode':   'kanban,list,form',
            'domain':      [('pack_id','=', self.id)],
            'context':     {'default_pack_id': self.id},
        }

    def action_open_licences(self):
        self.ensure_one()
        return {
            'name':        "Licences",
            'type':        'ir.actions.act_window',
            'res_model':   'parc.licence',
            'view_mode':   'kanban,list,form',
            'domain':      [('pack_id','=', self.id)],
            'context':     {'default_pack_id': self.id},
        }
