# -*- coding: utf-8 -*-
from odoo import models, fields

class ResPartner(models.Model):
    _inherit = 'res.partner'

    is_client_it = fields.Boolean(
        string="Client Parc Informatique",
        help="Indique si ce partenaire est un client pour la gestion du parc informatique."
    )
    client_type = fields.Selection([
        ('pme', 'PME'),
        ('admin', 'Administration'),
        ('groupe', 'Groupe Privé'),
        ('asso', 'Association')
    ], string="Type de Client")
    site_ids = fields.One2many(
        'parc.client.site',
        'client_id',
        string="Sites Associés"
    )
