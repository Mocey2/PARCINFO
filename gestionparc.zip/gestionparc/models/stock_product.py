from odoo import models, fields, api


class ProductTemplate(models.Model):
    _inherit = 'product.template'

    is_parc_product = fields.Boolean(
        string="Produit du Parc Informatique",
        help="Cochez si ce produit est destiné à la gestion du parc informatique."
    )

    equipement_type = fields.Selection([
        ('ordinateur', 'Ordinateur'),
        ('imprimante', 'Imprimante'),
        ('routeur', 'Routeur'),
        ('camera', 'Caméra'),
        ('consommable', 'Consommable')
    ], string="Type d’Équipement")

    marque = fields.Char(string="Marque")
    modele = fields.Char(string="Modèle")
    serial_number = fields.Char(string="N° de Série")

    etat_stock = fields.Selection([
        ('en_stock', 'En Stock'),
        ('affecte', 'Affecté'),
        ('retour', 'En Retour SAV'),
    ], string="État du Produit", default='en_stock')

    @api.model
    def default_get(self, fields_list):
        res = super().default_get(fields_list)
        if 'is_parc_product' in fields_list:
            res['is_parc_product'] = True
        if 'categ_id' in fields_list:
            default_category = self.env.ref('gestionparc.category_parc_informatique', raise_if_not_found=False)
            if default_category:
                res['categ_id'] = default_category.id
        return res
