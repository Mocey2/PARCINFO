# -*- coding: utf-8 -*-
from odoo import models, fields, api
from datetime import timedelta

class ParcMateriel(models.Model):
    _name = 'parc.materiel'
    _description = 'Matériel Informatique'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'date_purchase desc'

    pack_id = fields.Many2one('parc.pack', string="Pack", required=True, ondelete='cascade')
    product_id = fields.Many2one('product.product', string="Produit Stocké", required=True, domain=[('is_parc_product','=',True)])
    serial_number = fields.Char(string="N° de Série", required=True, copy=False, tracking=True)
    date_purchase = fields.Date(string="Date d’Achat", required=True, tracking=True)
    warranty_months = fields.Integer(string="Durée de Garantie (mois)", default=12)
    warranty_end = fields.Date(string="Fin de Garantie", compute='_compute_warranty_end', store=True)
    state = fields.Selection([
        ('en_stock', 'En Stock'),
        ('affecte', 'Affecté'),
        ('maintenance', 'En Maintenance'),
        ('retour', 'Retour SAV'),
    ], string="État", default='en_stock', tracking=True)
    notes = fields.Text(string="Notes / Historique")

    @api.depends('date_purchase', 'warranty_months')
    def _compute_warranty_end(self):
        for rec in self:
            if rec.date_purchase and rec.warranty_months is not None:
                rec.warranty_end = rec.date_purchase + timedelta(days=rec.warranty_months * 30)
            else:
                rec.warranty_end = False
