# -*- coding: utf-8 -*-
from odoo import models, fields

class ParcAffectation(models.Model):
    _name = 'parc.affectation'
    _description = 'Affectation Matériel/Licence'
    _order = 'date_from desc'

    pack_id = fields.Many2one('parc.pack', string="Pack", required=True, ondelete='cascade')
    materiel_id = fields.Many2one('parc.materiel', string="Matériel", ondelete='set null')
    licence_id = fields.Many2one('parc.licence', string="Licence", ondelete='set null')
    employee_id = fields.Many2one('hr.employee', string="Employé", required=True, ondelete='cascade')
    date_from = fields.Date(string="Date de début", required=True)
    date_to = fields.Date(string="Date de fin")
    notes = fields.Text(string="Commentaires")
