# -*- coding: utf-8 -*-
from odoo import models, fields, api
from datetime import timedelta

class ParcLicence(models.Model):
    _name = 'parc.licence'
    _description = 'Licence Informatique'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _order = 'date_expiry desc'

    pack_id = fields.Many2one(
        'parc.pack', string="Pack", required=True, ondelete='cascade'
    )
    logiciel_id = fields.Many2one(
        'parc.logiciel', string="Logiciel", required=True, ondelete='cascade'
    )
    date_start = fields.Date(
        string="Date d'attribution", required=True, tracking=True
    )
    duration_days = fields.Integer(
        string="Durée (jours)", required=True, tracking=True
    )
    date_expiry = fields.Date(
        string="Date d'expiration",
        compute='_compute_date_expiry',
        store=True,
        tracking=True
    )
    state = fields.Selection([
        ('draft',   'Brouillon'),
        ('active',  'Active'),
        ('expired', 'Expirée'),
    ], string="État", default='draft', tracking=True)
    notes = fields.Text(string="Notes")  # <-- nouveau champ

    @api.depends('date_start', 'duration_days')
    def _compute_date_expiry(self):
        for rec in self:
            if rec.date_start and rec.duration_days:
                rec.date_expiry = rec.date_start + timedelta(days=rec.duration_days)
            else:
                rec.date_expiry = False
