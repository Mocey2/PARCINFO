from odoo import models, fields


class PurchaseOrder(models.Model):
    _inherit = 'purchase.order'

    parc_order = fields.Boolean(
        string="Commande Parc Informatique",
        help="Commande liée aux achats de matériels pour Parc Informatique."
    )


class PurchaseOrderLine(models.Model):
    _inherit = 'purchase.order.line'

    is_parc_product = fields.Boolean(
        related='product_id.is_parc_product',
        string="Produit Parc Informatique",
        store=True
    )

    equipement_type = fields.Selection(
        related='product_id.equipement_type',
        string="Type d'Équipement",
        store=True
    )
