from . import client_site   # D'abord celui qui définit les modèles utilisés ailleurs
from . import res_partner   # Ensuite celui qui dépend du précédent
from . import stock_product
from . import stock_purchase
from . import parc_pack
from . import parc_materiel
from . import parc_logiciel
from . import parc_licence
from . import parc_affectation