# -*- coding: utf-8 -*-
from odoo import models, fields

class ClientSite(models.Model):
    _name = 'parc.client.site'
    _description = 'Site Client'

    name = fields.Char(string="Nom du site", required=True)
    contact_person = fields.Char(string="Contact")
    address = fields.Text(string="Adresse")
    phone = fields.Char(string="Téléphone")
    email = fields.Char(string="Email")
    intervention_hours = fields.Char(string="Horaires")
    client_id = fields.Many2one(
        'res.partner',
        string="Client",
        required=True,
        ondelete='restrict'
    )
