# -*- coding: utf-8 -*-
from odoo import models, fields

class ParcLogiciel(models.Model):
    _name = 'parc.logiciel'
    _description = 'Logiciel Installé'
    _inherit = ['mail.thread']
    _order = 'name'

    name = fields.Char(string="Nom du Logiciel", required=True, tracking=True)
    version = fields.Char(string="Version", tracking=True)
    pack_id = fields.Many2one('parc.pack', string="Pack", required=True, ondelete='cascade')
    product_id = fields.Many2one('product.template', string="Produit Logiciel", ondelete='set null')
    notes = fields.Text(string="Notes d’Installation")
