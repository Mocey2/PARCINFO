{
    'name': 'Gestion Parc Informatique',
    'version': '1.0',
    'summary': 'Gestion du Stock et des Achats pour Parc Informatique',
    'description': """
Module de gestion des matériels, logiciels et achats pour projet de parc informatique
    """,
    'category': 'Inventory',
    'author': 'TonNom',
    'website': 'https://tonsite.com',
    'depends': ['base', 'stock', 'purchase'],
    'data': [
        'security/ir.model.access.csv',
        'views/stock_product_views.xml',
        'views/stock_purchase_views.xml',
        'views/client_site_views.xml', 
        'views/res_partner_views.xml',
        'views/parc_pack_views.xml',
        'views/parc_materiel_views.xml',
        'views/parc_logiciel_views.xml',
        'views/parc_licence_views.xml',
        'views/parc_affectation_views.xml',



        'views/menu_views.xml',
    ],
    'installable': True,
    'application': True,
    'license': 'LGPL-3',

}
