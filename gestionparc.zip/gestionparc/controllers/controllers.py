# -*- coding: utf-8 -*-
# from odoo import http


# class Gestionparc(http.Controller):
#     @http.route('/gestionparc/gestionparc', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/gestionparc/gestionparc/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('gestionparc.listing', {
#             'root': '/gestionparc/gestionparc',
#             'objects': http.request.env['gestionparc.gestionparc'].search([]),
#         })

#     @http.route('/gestionparc/gestionparc/objects/<model("gestionparc.gestionparc"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('gestionparc.object', {
#             'object': obj
#         })

